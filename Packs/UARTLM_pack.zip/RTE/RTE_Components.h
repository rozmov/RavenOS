
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'UARTLM' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#include <stdint.h>
		#include <stdbool.h>
		#include "inc/hw_ints.h"
		#include "inc/hw_gpio.h"
		#include "inc/hw_types.h"
		#include "driverlib/debug.h"
		#include "driverlib/fpu.h"
		#include "driverlib/gpio.h"
		#include "driverlib/interrupt.h"
		#include "driverlib/pin_map.h"
		#include "driverlib/rom.h"
		#include "driverlib/sysctl.h"
		#include "driverlib/uart.h"
		#include "driverlib/rom_map.h"
		#define CMSIS_Drivers_USART0              /* Driver USART0 */

#endif /* RTE_COMPONENTS_H */
