#include "stdio.h"
#include "USART_TM4C123.h"

//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>UART Retargetting (output only supported)</h1>
//!
//! @brief Retargetting prints using UART. 
//!
//! The first UART (connected to the USB debug virtual serial port on the evaluation board)
//! will be configured in 115,200 baud, 8-n-1 mode. Printing a test string using CMSIS Driver
//! API and printing using stdio (if retargetted, it whould be printing to UART0 as well)
//
//*****************************************************************************

int
main(void)
{
	ARM_USART_SignalEvent_t cb_event;

	Driver_USART0.Initialize(cb_event);  		
  Driver_USART0.PowerControl(ARM_POWER_FULL);
	//
	// Configure the UART for 115,200, 8-N-1 operation.
	//	
	Driver_USART0.Control(ARM_USART_MODE_ASYNCHRONOUS,115200);
	Driver_USART0.Control(ARM_USART_CONTROL_TX,1);
	
  Driver_USART0.Send((uint8_t *)"Test\n\r", 6);
	printf ("Hello World\n\r");			
		
	//
	// Loop forever.
	//
	while(1)
	{

	}
}
