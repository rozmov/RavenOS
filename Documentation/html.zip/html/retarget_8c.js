var retarget_8c =
[
    [ "__FILE", "struct_____f_i_l_e.html", "struct_____f_i_l_e" ],
    [ "_sys_exit", "retarget_8c.html#a7b9ac395975163ef0a591db5c48ad7ae", null ],
    [ "_ttywrch", "retarget_8c.html#a1647e9479b4be5731d79c81af76826c5", null ],
    [ "ferror", "retarget_8c.html#a7d3d2b0c891c340cfaf0921aacfe392c", null ],
    [ "fgetc", "retarget_8c.html#a2c4fad5f95f4c5242c3ea25d791df6e5", null ],
    [ "fputc", "retarget_8c.html#abac7707b6be5733e890091048fcb99a2", null ],
    [ "UART0_getc", "retarget_8c.html#a5ac5f2408abcc3e49ecbb040dea425c8", null ],
    [ "UART0_putc", "retarget_8c.html#a0fef00a4590f8eeaa26eeacfa120e255", null ],
    [ "__stdin", "retarget_8c.html#abb2a819d3c88269eba04ea62d759bef5", null ],
    [ "__stdout", "retarget_8c.html#ac1f65ebf7d6f28fb49530ee0095306cb", null ]
];