var trace_8c =
[
    [ "MAX_STR_LEN", "trace_8c.html#a58ce36916c399104e18d32ff090f21c6", null ],
    [ "MAX_TRACE_ARR_LEN", "trace_8c.html#a74f9628c18bb6cce05ab31546fca35ba", null ],
    [ "MIN_TRACE_ARR_LEN", "trace_8c.html#a817e4ed18d4c052f1bf9bd7f8261e954", null ],
    [ "addTrace", "trace_8c.html#a0c045565a7872689752c456352835196", null ],
    [ "decrementTraceCounter", "trace_8c.html#ac86a8c7e8dec40007457bc35176ebd9f", null ],
    [ "dumpTrace", "trace_8c.html#aa78bb2aec0867c8b709cd3a1da3e2e34", null ],
    [ "getTraceCounter", "trace_8c.html#a71887a301d7504612011c655a127008d", null ],
    [ "incrementTraceCounter", "trace_8c.html#afde720d31599a848b0ad96d47dbaf555", null ],
    [ "trace_counter", "trace_8c.html#a34528aa0fa7eac7a27d7261fdf5dfd30", null ],
    [ "trace_table", "trace_8c.html#a9d2153983845df2f4ebea84362bdea94", null ]
];