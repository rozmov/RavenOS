var trace_8h =
[
    [ "TRACE_ERROR", "trace_8h.html#a7c12181b2e8dc912219651ff42d22e42", null ],
    [ "TRACE_OK", "trace_8h.html#abe999116692a0cf8829e4a39e07f7c23", null ],
    [ "addTrace", "trace_8h.html#a0c045565a7872689752c456352835196", null ],
    [ "addTraceProtected", "trace_8h.html#aaea4efb50e8356974a86292cf27ff202", null ],
    [ "dumpTrace", "trace_8h.html#aa78bb2aec0867c8b709cd3a1da3e2e34", null ],
    [ "dumpTraceProtected", "trace_8h.html#ae54c4f4a52896eeea181c2c4983cd1f3", null ],
    [ "getTraceCounter", "trace_8h.html#a71887a301d7504612011c655a127008d", null ]
];