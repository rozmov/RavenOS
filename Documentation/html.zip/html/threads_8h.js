var threads_8h =
[
    [ "DEFAULT_STACK_SIZE", "threads_8h.html#a87dcbc4991a2a2fc4eb6fc6a24449f26", null ],
    [ "MAX_THREADS", "threads_8h.html#a8b5173357adb02a86c027316e0acdfa0", null ],
    [ "osThreadStatus", "threads_8h.html#afb74ee1b0e49d183897bbe2dacd37cbb", null ],
    [ "os_thread_status", "threads_8h.html#a356483ad40f04f0a68cc364ad0e9c96c", [
      [ "TH_RUNNING", "threads_8h.html#a356483ad40f04f0a68cc364ad0e9c96ca9ef536c92b019be506ce8bef07fa2b03", null ],
      [ "TH_READY", "threads_8h.html#a356483ad40f04f0a68cc364ad0e9c96ca43ada29ec0a3d099fffd0f364d972b5e", null ],
      [ "TH_BLOCKED", "threads_8h.html#a356483ad40f04f0a68cc364ad0e9c96ca1ce9393902ad806168a031a081a4f1af", null ],
      [ "TH_ASLEEP", "threads_8h.html#a356483ad40f04f0a68cc364ad0e9c96ca94aea4d5b3836e58f0434560b9ba4598", null ],
      [ "TH_DEAD", "threads_8h.html#a356483ad40f04f0a68cc364ad0e9c96cac7a9514f0720db5451c1ab9dcc8e982b", null ]
    ] ]
];