var kernel_8h =
[
    [ "os_KernelInvokeScheduler", "kernel_8h.html#a405f8b5b73c549c942ea9915f57580ba", null ],
    [ "os_KernelStackAlloc", "kernel_8h.html#a2aad0b69b73fccfe5c4bfa13285b6e8e", null ]
];