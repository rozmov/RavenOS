var structos__semaphore__cb =
[
    [ "ownCount", "structos__semaphore__cb.html#aa6dae1d81408afbc800ff71fec45bf01", null ],
    [ "threads_own_q", "structos__semaphore__cb.html#a68a1a9ddde67104ff13b33cd643bcaa7", null ],
    [ "threads_own_q_cnt", "structos__semaphore__cb.html#af8a5702b9cd99535d756bc2acf2b9cc6", null ],
    [ "threads_q", "structos__semaphore__cb.html#a66a2d578f679aeb5463051aa1c7ae28e", null ],
    [ "threads_q_cnt", "structos__semaphore__cb.html#a76f9b59163105be835c46015b0cd9647", null ]
];