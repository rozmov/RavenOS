var annotated =
[
    [ "__FILE", "struct_____f_i_l_e.html", "struct_____f_i_l_e" ],
    [ "os_mailQ_def", "structos__mail_q__def.html", "structos__mail_q__def" ],
    [ "os_messageQ_def", "structos__message_q__def.html", "structos__message_q__def" ],
    [ "os_mutex_def", "structos__mutex__def.html", "structos__mutex__def" ],
    [ "os_pool_def", "structos__pool__def.html", "structos__pool__def" ],
    [ "os_semaphore_cb", "structos__semaphore__cb.html", "structos__semaphore__cb" ],
    [ "os_semaphore_def", "structos__semaphore__def.html", "structos__semaphore__def" ],
    [ "os_thread_cb", "structos__thread__cb.html", "structos__thread__cb" ],
    [ "os_thread_def", "structos__thread__def.html", "structos__thread__def" ],
    [ "os_thread_timed", "structos__thread__timed.html", "structos__thread__timed" ],
    [ "os_timer_def", "structos__timer__def.html", "structos__timer__def" ],
    [ "osEvent", "structos_event.html", "structos_event" ]
];