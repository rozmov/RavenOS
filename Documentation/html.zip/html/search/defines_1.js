var searchData=
[
  ['hw32_5freg',['HW32_REG',['../kernel_8c.html#aaa11c7df18ba462bf4c3da360d28f16b',1,'kernel.c']]]
];
