var searchData=
[
  ['stop_5fcpu',['stop_cpu',['../os_objects_8h.html#a83c0473f91377cf427259bb66650d5ab',1,'osObjects.h']]],
  ['stop_5fcpu2',['stop_cpu2',['../os_objects_8h.html#a90cb4ff3c8eb516c770c421a729a4eac',1,'osObjects.h']]]
];
