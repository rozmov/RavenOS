var searchData=
[
  ['uart0_5fgetc',['UART0_getc',['../retarget_8c.html#a5ac5f2408abcc3e49ecbb040dea425c8',1,'retarget.c']]],
  ['uart0_5fputc',['UART0_putc',['../retarget_8c.html#a0fef00a4590f8eeaa26eeacfa120e255',1,'retarget.c']]],
  ['uart_5finitialize',['UART_initialize',['../peripherals_8h.html#afec9f3d800b27c62145e1769d04827b4',1,'UART_initialize(void):&#160;peripherals.c'],['../peripherals_8c.html#afec9f3d800b27c62145e1769d04827b4',1,'UART_initialize(void):&#160;peripherals.c']]]
];
