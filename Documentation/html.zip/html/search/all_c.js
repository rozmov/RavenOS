var searchData=
[
  ['next_5ftask',['next_task',['../scheduler_8c.html#a2b9b764bed89b62bc2b1edf3f157fb5c',1,'scheduler.c']]]
];
