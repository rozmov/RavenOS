var searchData=
[
  ['owncount',['ownCount',['../structos__semaphore__cb.html#aa6dae1d81408afbc800ff71fec45bf01',1,'os_semaphore_cb']]]
];
