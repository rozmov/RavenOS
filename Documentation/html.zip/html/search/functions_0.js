var searchData=
[
  ['_5fsys_5fexit',['_sys_exit',['../retarget_8c.html#a7b9ac395975163ef0a591db5c48ad7ae',1,'retarget.c']]],
  ['_5fttywrch',['_ttywrch',['../retarget_8c.html#a1647e9479b4be5731d79c81af76826c5',1,'retarget.c']]]
];
