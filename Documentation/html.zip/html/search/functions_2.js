var searchData=
[
  ['count1sec',['count1Sec',['../peripherals_8h.html#ae9563b14d9b3ebfa06551e2eacb410c3',1,'count1Sec(void):&#160;peripherals.c'],['../peripherals_8c.html#ae9563b14d9b3ebfa06551e2eacb410c3',1,'count1Sec(void):&#160;peripherals.c']]]
];
