var searchData=
[
  ['p',['p',['../structos_event.html#a117104b82864d3b23ec174af6d392709',1,'osEvent']]],
  ['pool',['pool',['../structos__pool__def.html#a269c3935f8bc66db70bccdd02cb05e3c',1,'os_pool_def::pool()'],['../structos__message_q__def.html#a269c3935f8bc66db70bccdd02cb05e3c',1,'os_messageQ_def::pool()'],['../structos__mail_q__def.html#a269c3935f8bc66db70bccdd02cb05e3c',1,'os_mailQ_def::pool()']]],
  ['pool_5fsz',['pool_sz',['../structos__pool__def.html#ac112e786b2a234e0e45cb5bdbee53763',1,'os_pool_def']]],
  ['priority',['priority',['../structos__thread__cb.html#ad100ae36091f0ade0ec4c4012cd2bbaa',1,'os_thread_cb']]],
  ['pthread',['pthread',['../structos__thread__def.html#ad3c9624ee214329fb34e71f544a6933e',1,'os_thread_def']]],
  ['ptimer',['ptimer',['../structos__timer__def.html#a15773df83aba93f8e61f3737af5fae47',1,'os_timer_def']]]
];
