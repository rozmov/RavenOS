var searchData=
[
  ['queue_5fsz',['queue_sz',['../structos__message_q__def.html#a8a83a3a8c0aa8057b13807d2a54077e0',1,'os_messageQ_def::queue_sz()'],['../structos__mail_q__def.html#a8a83a3a8c0aa8057b13807d2a54077e0',1,'os_mailQ_def::queue_sz()']]]
];
