var searchData=
[
  ['decrementtracecounter',['decrementTraceCounter',['../trace_8c.html#ac86a8c7e8dec40007457bc35176ebd9f',1,'trace.c']]],
  ['def',['def',['../structos_event.html#a596b6d55c3321db19239256bbe403df6',1,'osEvent']]],
  ['default_5fstack_5fsize',['DEFAULT_STACK_SIZE',['../threads_8h.html#a87dcbc4991a2a2fc4eb6fc6a24449f26',1,'threads.h']]],
  ['delete_5fsemaphore0',['Delete_Semaphore0',['../os_objects_8h.html#a4c18ac6ca287bcf72fef77ac2664c723',1,'Delete_Semaphore0(void):&#160;sem0.c'],['../sem0_8c.html#a4c18ac6ca287bcf72fef77ac2664c723',1,'Delete_Semaphore0(void):&#160;sem0.c']]],
  ['delete_5fsemaphore1',['Delete_Semaphore1',['../os_objects_8h.html#a54be739d309f4a9c7855af4d6541d50b',1,'Delete_Semaphore1(void):&#160;sem1.c'],['../sem1_8c.html#a54be739d309f4a9c7855af4d6541d50b',1,'Delete_Semaphore1(void):&#160;sem1.c']]],
  ['dummy',['dummy',['../structos__mutex__def.html#a44b7a3baf02bac7ad707e8f2f5eca1ca',1,'os_mutex_def::dummy()'],['../structos__semaphore__def.html#a44b7a3baf02bac7ad707e8f2f5eca1ca',1,'os_semaphore_def::dummy()']]],
  ['dumptrace',['dumpTrace',['../trace_8h.html#aa78bb2aec0867c8b709cd3a1da3e2e34',1,'dumpTrace(void):&#160;trace.c'],['../trace_8c.html#aa78bb2aec0867c8b709cd3a1da3e2e34',1,'dumpTrace(void):&#160;trace.c']]],
  ['dumptraceprotected',['dumpTraceProtected',['../trace_8h.html#ae54c4f4a52896eeea181c2c4983cd1f3',1,'dumpTraceProtected(void):&#160;protectedTrace.c'],['../protected_trace_8c.html#ae54c4f4a52896eeea181c2c4983cd1f3',1,'dumpTraceProtected(void):&#160;protectedTrace.c']]]
];
