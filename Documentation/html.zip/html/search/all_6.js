var searchData=
[
  ['gettracecounter',['getTraceCounter',['../trace_8h.html#a71887a301d7504612011c655a127008d',1,'getTraceCounter(void):&#160;trace.c'],['../trace_8c.html#a71887a301d7504612011c655a127008d',1,'getTraceCounter(void):&#160;trace.c']]]
];
