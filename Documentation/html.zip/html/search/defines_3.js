var searchData=
[
  ['max_5fcount',['MAX_COUNT',['../peripherals_8c.html#ae14eaaed1fe7cdf491da54a714c426b3',1,'peripherals.c']]],
  ['max_5fsemaphores',['MAX_SEMAPHORES',['../cmsis__os_8h.html#a7d834905005d33312c6c3fc264247ab5',1,'cmsis_os.h']]],
  ['max_5fstr_5flen',['MAX_STR_LEN',['../trace_8c.html#a58ce36916c399104e18d32ff090f21c6',1,'trace.c']]],
  ['max_5fthreads',['MAX_THREADS',['../threads_8h.html#a8b5173357adb02a86c027316e0acdfa0',1,'threads.h']]],
  ['max_5fthreads_5fsem',['MAX_THREADS_SEM',['../semaphores_8h.html#a028b23dd8de6ebbc0cea39cac48ab2a3',1,'semaphores.h']]],
  ['max_5ftrace_5farr_5flen',['MAX_TRACE_ARR_LEN',['../trace_8c.html#a74f9628c18bb6cce05ab31546fca35ba',1,'trace.c']]],
  ['min_5ftrace_5farr_5flen',['MIN_TRACE_ARR_LEN',['../trace_8c.html#a817e4ed18d4c052f1bf9bd7f8261e954',1,'trace.c']]]
];
