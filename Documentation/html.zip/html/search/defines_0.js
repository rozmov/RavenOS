var searchData=
[
  ['default_5fstack_5fsize',['DEFAULT_STACK_SIZE',['../threads_8h.html#a87dcbc4991a2a2fc4eb6fc6a24449f26',1,'threads.h']]]
];
