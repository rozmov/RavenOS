var searchData=
[
  ['handle',['handle',['../struct_____f_i_l_e.html#a3127ebf018e9da62fa464d348352037d',1,'__FILE']]]
];
