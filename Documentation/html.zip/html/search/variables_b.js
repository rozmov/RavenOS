var searchData=
[
  ['sem_5fcounter',['sem_counter',['../semaphores_8c.html#a4711d20103e7164651d13554d9429c1c',1,'semaphores.c']]],
  ['semaphore_5fid',['semaphore_id',['../structos__thread__cb.html#a5fc79f3ec6b8b7d81b131ca1a8ebea7c',1,'os_thread_cb']]],
  ['semaphore_5fp',['semaphore_p',['../structos__thread__cb.html#abc447699e3bbb1df80e5a0085c55e485',1,'os_thread_cb']]],
  ['semaphores',['semaphores',['../semaphores_8c.html#ac9fbe5ca618ef8eb98dbe9b0e632f85b',1,'semaphores.c']]],
  ['sid_5fsemaphore0',['sid_Semaphore0',['../os_objects_8h.html#ae9ce7d64772370bb23c2f53affd72d28',1,'sid_Semaphore0():&#160;sem0.c'],['../sem0_8c.html#ae9ce7d64772370bb23c2f53affd72d28',1,'sid_Semaphore0():&#160;sem0.c']]],
  ['sid_5fsemaphore1',['sid_Semaphore1',['../os_objects_8h.html#a1683fd12ff81dd77de1110c90994bf99',1,'sid_Semaphore1():&#160;sem1.c'],['../sem1_8c.html#a1683fd12ff81dd77de1110c90994bf99',1,'sid_Semaphore1():&#160;sem1.c']]],
  ['signals',['signals',['../structos_event.html#ad0dda1bf7e74f1576261d493fba232b6',1,'osEvent']]],
  ['stack_5fp',['stack_p',['../structos__thread__cb.html#a60f7563c51cf1fd0c0a8d398b5760f3f',1,'os_thread_cb']]],
  ['stack_5fsize',['stack_size',['../structos__thread__cb.html#ad63716408aae5b50857ca8ce74e3a3ff',1,'os_thread_cb']]],
  ['stacksize',['stacksize',['../structos__thread__def.html#a950b7f81ad4711959517296e63bc79d1',1,'os_thread_def']]],
  ['start_5fp',['start_p',['../structos__thread__cb.html#ad30f07be222f76b66cf0643bc6bf5e7d',1,'os_thread_cb']]],
  ['status',['status',['../structos__thread__cb.html#aeeef886d6a9f446fbde86382da133fb8',1,'os_thread_cb::status()'],['../structos_event.html#ad477a289f1f03ac45407b64268d707d3',1,'osEvent::status()']]],
  ['systemcoreclock',['SystemCoreClock',['../system___t_m4_c123_8c.html#aa3cd3e43291e81e795d642b79b6088e6',1,'system_TM4C123.c']]]
];
