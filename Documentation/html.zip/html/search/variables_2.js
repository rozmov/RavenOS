var searchData=
[
  ['def',['def',['../structos_event.html#a596b6d55c3321db19239256bbe403df6',1,'osEvent']]],
  ['dummy',['dummy',['../structos__mutex__def.html#a44b7a3baf02bac7ad707e8f2f5eca1ca',1,'os_mutex_def::dummy()'],['../structos__semaphore__def.html#a44b7a3baf02bac7ad707e8f2f5eca1ca',1,'os_semaphore_def::dummy()']]]
];
