var searchData=
[
  ['_5f_5fstdin',['__stdin',['../retarget_8c.html#abb2a819d3c88269eba04ea62d759bef5',1,'retarget.c']]],
  ['_5f_5fstdout',['__stdout',['../retarget_8c.html#ac1f65ebf7d6f28fb49530ee0095306cb',1,'retarget.c']]]
];
