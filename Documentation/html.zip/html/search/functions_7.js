var searchData=
[
  ['incrementtracecounter',['incrementTraceCounter',['../trace_8c.html#afde720d31599a848b0ad96d47dbaf555',1,'trace.c']]],
  ['init_5fsemaphore0',['Init_Semaphore0',['../os_objects_8h.html#ad7d3b946e778b32a3ec7405f51ac6c4a',1,'Init_Semaphore0(void):&#160;sem0.c'],['../sem0_8c.html#ad7d3b946e778b32a3ec7405f51ac6c4a',1,'Init_Semaphore0(void):&#160;sem0.c']]],
  ['init_5fsemaphore1',['Init_Semaphore1',['../os_objects_8h.html#ac8c670714758ce70ef6c7d14fb41b016',1,'Init_Semaphore1(void):&#160;sem1.c'],['../sem1_8c.html#ac8c670714758ce70ef6c7d14fb41b016',1,'Init_Semaphore1(void):&#160;sem1.c']]],
  ['init_5fthread0',['Init_thread0',['../os_objects_8h.html#a2a70e03dc85e518b7c1ad37b9f4ecb35',1,'Init_thread0(void):&#160;thread0.c'],['../thread0_8c.html#a2a70e03dc85e518b7c1ad37b9f4ecb35',1,'Init_thread0(void):&#160;thread0.c']]],
  ['init_5fthread1',['Init_thread1',['../os_objects_8h.html#abb3abc75a433c332f5fde4f5b889fb05',1,'Init_thread1(void):&#160;thread1.c'],['../thread1_8c.html#abb3abc75a433c332f5fde4f5b889fb05',1,'Init_thread1(void):&#160;thread1.c']]],
  ['init_5fthread2',['Init_thread2',['../os_objects_8h.html#ae8780d78ea250bba4edce3221a4acdc1',1,'Init_thread2(void):&#160;thread2.c'],['../thread2_8c.html#ae8780d78ea250bba4edce3221a4acdc1',1,'Init_thread2(void):&#160;thread2.c']]],
  ['init_5fthread3',['Init_thread3',['../os_objects_8h.html#a4ded95b8829e5de74a4b3760a62cc82a',1,'Init_thread3(void):&#160;thread3.c'],['../thread3_8c.html#a4ded95b8829e5de74a4b3760a62cc82a',1,'Init_thread3(void):&#160;thread3.c']]],
  ['init_5fthreadidle',['Init_threadIdle',['../thread_idle_8h.html#a5e8a347d5d15ac589be66e14c120acf9',1,'Init_threadIdle(void):&#160;threadIdle.c'],['../thread_idle_8c.html#a5e8a347d5d15ac589be66e14c120acf9',1,'Init_threadIdle(void):&#160;threadIdle.c']]]
];
