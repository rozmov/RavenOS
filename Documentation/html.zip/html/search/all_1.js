var searchData=
[
  ['addtrace',['addTrace',['../trace_8h.html#a0c045565a7872689752c456352835196',1,'addTrace(char *message):&#160;trace.c'],['../trace_8c.html#a0c045565a7872689752c456352835196',1,'addTrace(char *message):&#160;trace.c']]],
  ['addtraceprotected',['addTraceProtected',['../trace_8h.html#aaea4efb50e8356974a86292cf27ff202',1,'addTraceProtected(char *message):&#160;protectedTrace.c'],['../protected_trace_8c.html#aaea4efb50e8356974a86292cf27ff202',1,'addTraceProtected(char *message):&#160;protectedTrace.c']]]
];
