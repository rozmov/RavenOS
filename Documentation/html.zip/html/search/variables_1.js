var searchData=
[
  ['counter',['counter',['../peripherals_8c.html#a61f7b3cbcedea4bae0c663c892d5d07f',1,'peripherals.c']]],
  ['curr_5ftask',['curr_task',['../scheduler_8c.html#a0f6665bff2ea2135202f5f12a38cbe17',1,'scheduler.c']]]
];
