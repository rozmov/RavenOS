var searchData=
[
  ['mail_5fid',['mail_id',['../structos_event.html#ac86175a4b1706bee596f3018322df26e',1,'osEvent']]],
  ['message_5fid',['message_id',['../structos_event.html#af394cbe21dde7377974e63af38cd87b0',1,'osEvent']]]
];
