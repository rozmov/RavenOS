var searchData=
[
  ['instances',['instances',['../structos__thread__def.html#aa4c4115851a098c0b87358ab6c025603',1,'os_thread_def']]],
  ['item_5fsz',['item_sz',['../structos__pool__def.html#a4c2a0c691de3365c00ecd22d8102811f',1,'os_pool_def::item_sz()'],['../structos__message_q__def.html#a4c2a0c691de3365c00ecd22d8102811f',1,'os_messageQ_def::item_sz()'],['../structos__mail_q__def.html#a4c2a0c691de3365c00ecd22d8102811f',1,'os_mailQ_def::item_sz()']]]
];
