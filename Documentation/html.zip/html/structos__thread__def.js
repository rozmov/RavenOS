var structos__thread__def =
[
    [ "instances", "structos__thread__def.html#aa4c4115851a098c0b87358ab6c025603", null ],
    [ "pthread", "structos__thread__def.html#ad3c9624ee214329fb34e71f544a6933e", null ],
    [ "stacksize", "structos__thread__def.html#a950b7f81ad4711959517296e63bc79d1", null ],
    [ "tpriority", "structos__thread__def.html#a15da8f23c6fe684b70a73646ada685e7", null ]
];