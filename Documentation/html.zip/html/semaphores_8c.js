var semaphores_8c =
[
    [ "osSemaphore", "semaphores_8c.html#a03761ee8d2c3cd4544e18364ab301dac", null ],
    [ "osSemaphoreDef", "semaphores_8c.html#a9e66fe361749071e5ab87826c43c2f1b", null ],
    [ "os_InsertThreadInSemaphoreBlockedQ", "semaphores_8c.html#a28c78166c50f06807a4290f9f8a37d26", null ],
    [ "os_InsertThreadInSemaphoreOwnerQ", "semaphores_8c.html#a3387b88698b0cb050a17350b79c7789f", null ],
    [ "os_RemoveThreadFromSemaphoreBlockedQ", "semaphores_8c.html#a734d95b68a29cf25b71adffba5a1f181", null ],
    [ "os_RemoveThreadFromSemaphoreOwnerQ", "semaphores_8c.html#afbe20b19f5aec1e27c5643542adfd544", null ],
    [ "os_SearchThreadAllSemaphoresBlockedQ", "semaphores_8c.html#abbeb4c0c442b5f70874904914f90b92d", null ],
    [ "os_SearchThreadInSemaphoreBlockedQ", "semaphores_8c.html#a7badc8243de28cde5ce32e7514f66b89", null ],
    [ "os_SearchThreadInSemaphoreOwnerQ", "semaphores_8c.html#aa46a19b54de67d23b7416fd37df16990", null ],
    [ "os_SearchThreadSemaphoresExcept", "semaphores_8c.html#acf078b9bd476f8f8e386787a8249520a", null ],
    [ "os_SemaphoreRemoveThread", "semaphores_8c.html#af8d8c5423ede32da632de69a9ad4e804", null ],
    [ "osSemaphoreCreate", "semaphores_8c.html#a97381e8e55cd47cec390bf57c96d6edb", null ],
    [ "osSemaphoreDelete", "semaphores_8c.html#abae2801ac2c096f6e8c69a264908f595", null ],
    [ "osSemaphoreRelease", "semaphores_8c.html#ab108914997c49e14d8ff1ae0d1988ca0", null ],
    [ "osSemaphoreWait", "semaphores_8c.html#acc15b0fc8ce1167fe43da33042e62098", null ],
    [ "sem_counter", "semaphores_8c.html#a4711d20103e7164651d13554d9429c1c", null ],
    [ "semaphores", "semaphores_8c.html#ac9fbe5ca618ef8eb98dbe9b0e632f85b", null ]
];