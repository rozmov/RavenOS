var thread_idle_8h =
[
    [ "Init_threadIdle", "thread_idle_8h.html#a5e8a347d5d15ac589be66e14c120acf9", null ],
    [ "threadIdle", "thread_idle_8h.html#a2d0620772fa9959681d65514b0fb19db", null ]
];