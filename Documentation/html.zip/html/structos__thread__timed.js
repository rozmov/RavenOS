var structos__thread__timed =
[
    [ "expiryTime", "structos__thread__timed.html#ae4a5db620da699add5689ed19907bd9d", null ],
    [ "threadId", "structos__thread__timed.html#a39f9cbcf4fe571834e78dee82b87476a", null ],
    [ "ticks", "structos__thread__timed.html#ab3507a48ae247ff252738ca350810b21", null ]
];