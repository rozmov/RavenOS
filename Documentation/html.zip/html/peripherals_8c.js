var peripherals_8c =
[
    [ "LED_BLUE", "peripherals_8c.html#ae2e40566d27689f8581d7b0f12271d45", null ],
    [ "LED_GREEN", "peripherals_8c.html#aca338dbd19d7940923334629f6e5f3b7", null ],
    [ "LED_RED", "peripherals_8c.html#a31e20330f8ce94e0dd10b005a15c5898", null ],
    [ "MAX_COUNT", "peripherals_8c.html#ae14eaaed1fe7cdf491da54a714c426b3", null ],
    [ "count1Sec", "peripherals_8c.html#ae9563b14d9b3ebfa06551e2eacb410c3", null ],
    [ "LED_blink", "peripherals_8c.html#a148e57ed8da14984f743a7b120b1d489", null ],
    [ "LED_initialize", "peripherals_8c.html#a1a20b70d3e6a3181b0f9c75f371d8ded", null ],
    [ "UART_initialize", "peripherals_8c.html#afec9f3d800b27c62145e1769d04827b4", null ],
    [ "counter", "peripherals_8c.html#a61f7b3cbcedea4bae0c663c892d5d07f", null ]
];