var scheduler_8c =
[
    [ "os_ReevaluateBlockedThread", "scheduler_8c.html#a1a01d4efabc04644e0d0e6a21e5ee60b", null ],
    [ "os_ReevaluateThread", "scheduler_8c.html#a55fbac450d43684ac8f3bbf62988acba", null ],
    [ "os_ThreadGetBestThread", "scheduler_8c.html#a1ff6e48580c53794a0f09a4e8cc8f6de", null ],
    [ "os_ThreadGetNextThread", "scheduler_8c.html#aef04ef03a005f71eeff67c31624a251b", null ],
    [ "scheduler", "scheduler_8c.html#a9fa00b0be5d3c4781048861e2506eb63", null ],
    [ "curr_task", "scheduler_8c.html#a0f6665bff2ea2135202f5f12a38cbe17", null ],
    [ "next_task", "scheduler_8c.html#a2b9b764bed89b62bc2b1edf3f157fb5c", null ]
];