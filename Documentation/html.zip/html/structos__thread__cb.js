var structos__thread__cb =
[
    [ "priority", "structos__thread__cb.html#ad100ae36091f0ade0ec4c4012cd2bbaa", null ],
    [ "semaphore_id", "structos__thread__cb.html#a5fc79f3ec6b8b7d81b131ca1a8ebea7c", null ],
    [ "semaphore_p", "structos__thread__cb.html#abc447699e3bbb1df80e5a0085c55e485", null ],
    [ "stack_p", "structos__thread__cb.html#a60f7563c51cf1fd0c0a8d398b5760f3f", null ],
    [ "stack_size", "structos__thread__cb.html#ad63716408aae5b50857ca8ce74e3a3ff", null ],
    [ "start_p", "structos__thread__cb.html#ad30f07be222f76b66cf0643bc6bf5e7d", null ],
    [ "status", "structos__thread__cb.html#aeeef886d6a9f446fbde86382da133fb8", null ],
    [ "th_q_p", "structos__thread__cb.html#a76ad6cd76d5c0eaab6fda5599ffb94a7", null ],
    [ "time_count", "structos__thread__cb.html#a27a5ca530d748bfab882b25364198701", null ],
    [ "timed_q_p", "structos__thread__cb.html#a5616d1c770a068e3efa4db20eea081ae", null ],
    [ "timed_ret", "structos__thread__cb.html#ad317a861ecd16ef34fb44eeae953b794", null ]
];