var structos__pool__def =
[
    [ "item_sz", "structos__pool__def.html#a4c2a0c691de3365c00ecd22d8102811f", null ],
    [ "pool", "structos__pool__def.html#a269c3935f8bc66db70bccdd02cb05e3c", null ],
    [ "pool_sz", "structos__pool__def.html#ac112e786b2a234e0e45cb5bdbee53763", null ]
];