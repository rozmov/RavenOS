var peripherals_8h =
[
    [ "LED0", "peripherals_8h.html#ae8d5b4e7e2d9d21caaa4744d385d7cc7", null ],
    [ "LED1", "peripherals_8h.html#a8aa85ae9867fabf70ec72cd3bf6fb6b9", null ],
    [ "LED2", "peripherals_8h.html#ad09fe5bf321b9a2de26bd5e5b9af6424", null ],
    [ "count1Sec", "peripherals_8h.html#ae9563b14d9b3ebfa06551e2eacb410c3", null ],
    [ "LED_blink", "peripherals_8h.html#a0e456ffdaacb58c029dfd606fa350c36", null ],
    [ "LED_initialize", "peripherals_8h.html#a1a20b70d3e6a3181b0f9c75f371d8ded", null ],
    [ "UART_initialize", "peripherals_8h.html#afec9f3d800b27c62145e1769d04827b4", null ]
];