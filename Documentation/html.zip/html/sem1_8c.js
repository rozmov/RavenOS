var sem1_8c =
[
    [ "Delete_Semaphore1", "sem1_8c.html#a54be739d309f4a9c7855af4d6541d50b", null ],
    [ "Init_Semaphore1", "sem1_8c.html#ac8c670714758ce70ef6c7d14fb41b016", null ],
    [ "osSemaphoreDef", "sem1_8c.html#aceb6f9f211845fc0a212c56c9e942d5d", null ],
    [ "sid_Semaphore1", "sem1_8c.html#a1683fd12ff81dd77de1110c90994bf99", null ]
];