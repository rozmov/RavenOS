var structos_event =
[
    [ "def", "structos_event.html#a596b6d55c3321db19239256bbe403df6", null ],
    [ "mail_id", "structos_event.html#ac86175a4b1706bee596f3018322df26e", null ],
    [ "message_id", "structos_event.html#af394cbe21dde7377974e63af38cd87b0", null ],
    [ "p", "structos_event.html#a117104b82864d3b23ec174af6d392709", null ],
    [ "signals", "structos_event.html#ad0dda1bf7e74f1576261d493fba232b6", null ],
    [ "status", "structos_event.html#ad477a289f1f03ac45407b64268d707d3", null ],
    [ "v", "structos_event.html#a9e0a00edabf3b8a5dafff624fff7bbfc", null ],
    [ "value", "structos_event.html#a0b9f8fd3645f01d8cb09cae82add2d7f", null ]
];