var semaphores_8h =
[
    [ "MAX_THREADS_SEM", "semaphores_8h.html#a028b23dd8de6ebbc0cea39cac48ab2a3", null ]
];