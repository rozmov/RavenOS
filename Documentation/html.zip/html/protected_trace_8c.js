var protected_trace_8c =
[
    [ "TRACE_FLAG", "protected_trace_8c.html#ada3b1f9f345b10e9c243b35634325846", null ],
    [ "addTraceProtected", "protected_trace_8c.html#aaea4efb50e8356974a86292cf27ff202", null ],
    [ "dumpTraceProtected", "protected_trace_8c.html#ae54c4f4a52896eeea181c2c4983cd1f3", null ]
];