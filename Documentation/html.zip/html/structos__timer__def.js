var structos__timer__def =
[
    [ "ptimer", "structos__timer__def.html#a15773df83aba93f8e61f3737af5fae47", null ]
];