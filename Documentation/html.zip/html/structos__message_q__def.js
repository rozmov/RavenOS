var structos__message_q__def =
[
    [ "item_sz", "structos__message_q__def.html#a4c2a0c691de3365c00ecd22d8102811f", null ],
    [ "pool", "structos__message_q__def.html#a269c3935f8bc66db70bccdd02cb05e3c", null ],
    [ "queue_sz", "structos__message_q__def.html#a8a83a3a8c0aa8057b13807d2a54077e0", null ]
];